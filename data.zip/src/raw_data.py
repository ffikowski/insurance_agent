import os
from pdfminer.high_level import extract_text

class DataLoader:
    """
    A class responsible for loading text data from PDF files in a specified directory,
    using the pdfminer library to extract text from PDFs.
    """

    def __init__(self, directory):
        """
        Initializes the DataLoader with the directory containing PDF files.

        Args:
            directory (str): The path to the directory where PDF files are stored.
        """
        self.directory = directory

    def get_file_paths(self):
        """
        Retrieves the file paths of all PDF files in the specified directory.

        Returns:
            list: A list of file paths for the PDF documents.
        """
        paths = []
        for filename in os.listdir(self.directory):
            path = os.path.join(self.directory, filename)
            if os.path.isfile(path):
                paths.append(path)
        return paths
    
    def pdfminer_pdftotext(self, pdf_path):
        """
        Extracts text from a PDF file using the pdfminer library.

        Args:
            pdf_path (str): The file path to the PDF document from which to extract text.

        Returns:
            str: The text extracted from the specified PDF file.
        """
        text = extract_text(pdf_path)
        return text
    
    def gen_corpus(self):
        """
        Generates a corpus by extracting text from each PDF file in the directory.

        Returns:
            list of str: A list containing the text of each PDF document in the corpus.
        """
        paths = self.get_file_paths()
        corpus = [self.pdfminer_pdftotext(path) for path in paths]
        return corpus
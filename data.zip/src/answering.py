import numpy as np
import os
import openai
from openai import OpenAI

class AnswerGenerator:
    """
    A class to generate answers for given questions using the OpenAI API and a local database
    for calculating similarities between text embeddings.
    """
    def __init__(self, database):
        """
        Initializes the AnswerGenerator instance.

        Args:
        database (pd.DataFrame): A pandas DataFrame that includes chunks of texts and their embeddings.
        """
        self.database = database
        self.client = OpenAI()
        openai.api_key = os.getenv('OPENAI_API_KEY')
        
    def cosine_similarity(self, A, B):
        """
        Computes the cosine similarity between two vectors.

        Args:
        A (np.ndarray): First vector.
        B (np.ndarray): Second vector.

        Returns:
        float: Cosine similarity between vectors A and B.
        """
        dot_product = np.dot(A, B)
        norm_A = np.linalg.norm(A)
        norm_B = np.linalg.norm(B)
        similarity = dot_product / (norm_A * norm_B)

        return similarity
    
    def get_embedding(self, text, model="text-embedding-3-small"):
        """
        Retrieves the text embedding from the OpenAI API.

        Args:
        text (str): Text to be embedded.
        model (str): Model identifier for the embedding.

        Returns:
        np.ndarray: The embedding of the input text.
        """
        text = text.replace("\n", " ")
        return self.client.embeddings.create(input = [text], model=model, dimensions=256).data[0].embedding
    
    def get_top_chunks(self, question):
        """
        Identifies and retrieves top chunks from the database based on similarity to the question.

        Args:
        question (str): The question text.

        Returns:
        list: Top chunks from the database along with their topic context.
        """
        num_top_answers = 5
        question_emb = self.get_embedding(question, model='text-embedding-3-small')
        self.database['similarity_score'] = [self.cosine_similarity(chunk_emb, question_emb) for chunk_emb in self.database['ada_embedding']]
        self.database.sort_values(by="similarity_score", inplace=True, ascending=False)
        top_chunks = list(self.database['chunk'].iloc[:num_top_answers])
        top_topics = list(self.database['topics'].iloc[:num_top_answers])
        top_answers = list(zip(top_chunks, top_topics))
        self.database.drop(columns=['similarity_score'], inplace=True)
        print(top_answers)
        return top_answers
    
    def get_content_string(self, top_answers, question):
        """
        Constructs a content string to be used for querying the OpenAI API.

        Args:
        top_answers (list): List of tuples with text chunks and context topics.
        question (str): The question text.

        Returns:
        str: Formatted string combining instructions and text chunks for the API.
        """
        num_top_answers = len(top_answers)
        base_string = f"Sie sind ein Fragen beantwortender Agent. Sie erhalten {num_top_answers} Textabschnitte aus einer Sammlung von verschiedenen Versicherungsdokumenten. Zu jedem dieser Textabschnitte gibt es eine Liste von Wörtern, die den Kontext des Dokuments beschreiben, aus dem der Text Abschnitt stammt. \n\nSie sollen anhand der Textabschnitte und dem Kontext die folgende Frage beantworten: {question} \nBeantworten Sie ausschließlich die Frage.\nDies sind die fünf Chunks, aus denen Sie die richtigen Informationen abrufen sollten: \n\n"
        variable_string = ''.join([f"{count+1}. Textabschnitt: {answer[0]}, Kontext: {answer[1]} \n" for count, answer in enumerate(top_answers)])
        content_string = base_string + variable_string
        return content_string
    
    def chats_answer(self, content_string):
        """
        Retrieves the answer from the OpenAI API by sending a stream request.

        Args:
        content_string (str): The formatted string query for the API.

        Returns:
        str: The accumulated response from the API as a single string.
        """
        full_response = ""
        
        stream = self.client.chat.completions.create(
            model="gpt-4",
            messages=[{"role": "user", "content": content_string}],
            stream=True,
        )
        for chunk in stream:
            if chunk.choices[0].delta.content is not None:
                full_response += chunk.choices[0].delta.content

        return full_response
    
    def trigger_answer(self, question):
        """
        Triggers the entire process to generate an answer for a given question.

        Args:
        question (str): The question for which an answer is needed.

        Returns:
        str: The generated answer.
        """
        top_answers = self.get_top_chunks(question)
        content_string = self.get_content_string(top_answers, question)
        answer = self.chats_answer(content_string)
        return answer
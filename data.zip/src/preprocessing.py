import pandas as pd
import re

class Preprocessor:
    """
    A class that preprocesses a corpus of documents to prepare them for further
    analysis or machine learning tasks. This includes text normalization, chunking,
    sentence splitting, and duplicate removal.
    """

    def __init__(self, corpus):
        """
        Initializes the Preprocessor with a corpus of documents.

        Args:
            corpus (list of str): A list containing document texts as strings.
        """
        self.corpus = corpus

    def clean_data(self):
        """
        Performs initial text replacements to normalize abbreviations and common terms,
        and substitutes some names to maintain anonymity.
        """
        corpus_preprocessed = []

        for document in self.corpus:
            document = document.replace("max.", "maximal")
            document = document.replace("Mio.", "Millionen")
            document = document.replace("inkl.", "inklusive")
            document = document.replace("z. B.", "zum Beispiel")
            document = document.replace("€", "Euro")
            document = document.replace(" Mo ", "Montag")
            document = document.replace(" Di ", "Dienstag")
            document = document.replace(" Mi ", "Mittwoch")
            document = document.replace(" Do ", "Donnerstag")
            document = document.replace(" Fr ", "Freitag")
            document = document.replace(" Sa ", "Samstag")
            document = document.replace(" So ", "Sonntag")
            document = document.replace("e. V.", "eingetragener Verein")
            document = document.replace("e. V.", "eingetragener Verein")
            document = document.replace("Dr.", "Doktor")
            document = document.replace("PHV", "Privat-Haftpflichtversicherung")
            document = document.replace("Felix", "Max")
            document = document.replace("Fikowski", "Mustermann")
            corpus_preprocessed.append(document)

        self.corpus = corpus_preprocessed
            
    def first_chunker(self):
        """
        Splits each document into chunks based on double newline characters, assuming
        each represents a paragraph or section.
        """
        self.corpus = [document.split('\n\n') for document in self.corpus]

    def cleaner(self, chunked_doc):
        """
        Cleans a chunked document by replacing newline characters with spaces.

        Args:
            chunked_doc (list of str): A document split into chunks.

        Returns:
            list of str: Cleaned chunks.
        """
        return [chunk.replace("\n", " ") for chunk in chunked_doc]
    
    def remove_multiple_whitespaces(self, chunked_doc):
        """
        Removes multiple whitespaces in each chunk to a single space.

        Args:
            chunked_doc (list of str): A document with chunks.

        Returns:
            list of str: Chunks with normalized spaces.
        """
        return [re.sub(r'\s+', ' ', chunk) for chunk in chunked_doc]
    
    def chunker2(self, chunked_doc):
        """
        Further refines chunks by merging very short subsequent chunks with previous ones,
        assuming they are likely to be part of the same section.

        Args:
            chunked_doc (list of str): A document split into initial chunks.

        Returns:
            list of str: Refined chunks.
        """
        chunks = []
        chunks.append(chunked_doc[0])

        for count in range(1, len(chunked_doc)):

            if len(chunked_doc[count]) < 15:
                chunks[-1] = chunks[-1] + ' ' + chunked_doc[count]
            else:
                chunk = chunked_doc[count]
                chunks.append(chunk)
                
        return chunks
    
    def split_sentence(self, chunked_doc):
        """
        Splits each chunk into sentences based on punctuation marks.

        Args:
            chunked_doc (list of str): A document split into refined chunks.

        Returns:
            list of str: Sentences.
        """
        return [sentence for chunk in chunked_doc for sentence in re.split(r'(?<=[a-z]{2}[.?!])\s+(?=[A-Z])', chunk)]
    
    def split_questions(self, chunked_doc):
        """
        Splits chunks into segments based on question marks, useful for extracting questions.

        Args:
            chunked_doc (list of str): A document split into sentences.

        Returns:
            list of str: Question segments.
        """
        return [sentence for chunk in chunked_doc for sentence in re.split(r'(?<=\?)(?=[A-Z\s])', chunk)]
    
    def remove_duplicates(self, chunked_doc):
        """
        Removes duplicate chunks within a document to ensure uniqueness.

        Args:
            chunked_doc (list of str): A document split into sentences or questions.

        Returns:
            list of str: Unique chunks or sentences.
        """
        unique_doc = []
        [unique_doc.append(chunk) for chunk in chunked_doc if chunk not in unique_doc]
        return unique_doc
    
    def create_overlapping_pairs(self, original_list):
        """
        Creates overlapping pairs from a list of strings, used to create context pairs or n-grams.

        Args:
            original_list (list of str): The list from which to create pairs.

        Returns:
            list of str: Overlapping pairs.
        """
        # Initialize an empty list to store the result
        overlapped_list = []
        # Iterate through the original list, except the last element
        for i in range(len(original_list) - 1):
            # Concatenate the current string with the next one
            overlapped_pair = original_list[i] + original_list[i + 1]
            # Append the concatenated string to the result list
            overlapped_list.append(overlapped_pair)
        return overlapped_list
    
    def second_chunker(self):
        """
        Applies a sequence of cleaning and refining functions to the corpus to prepare it for analysis or machine learning.
        """
        self.corpus = [self.cleaner(doc) for doc in self.corpus]
        self.corpus = [self.remove_multiple_whitespaces(doc) for doc in self.corpus]
        self.corpus = [self.chunker2(doc) for doc in self.corpus]
        self.corpus = [self.split_sentence(doc) for doc in self.corpus]
        self.corpus = [self.split_questions(doc) for doc in self.corpus]
        self.corpus = [self.remove_duplicates(doc) for doc in self.corpus]
        self.corpus = [self.remove_multiple_whitespaces(doc) for doc in self.corpus]
        self.corpus = [self.create_overlapping_pairs(doc) for doc in self.corpus]

    def create_dataframe(self):
        """
        Creates a pandas DataFrame from the processed corpus, indexing chunks by document ID.

        Returns:
            pd.DataFrame: A DataFrame with two columns: 'doc_id' and 'chunk'.
        """
        document_chunks_map = {}
        for index, document_chunks in enumerate(self.corpus):
            document_chunks_map[index] = document_chunks

        chunks_data = [(key, chunk) for key, chunks in document_chunks_map.items() for chunk in chunks]

        df_chunks = pd.DataFrame(chunks_data, columns=['doc_id', 'chunk'])

        return df_chunks
    
    def trigger_preprocessing(self):
        """
        Triggers the full preprocessing workflow from initial cleaning to DataFrame creation.

        Returns:
            pd.DataFrame: A DataFrame containing preprocessed document chunks indexed by document ID.
        """
        self.clean_data()
        self.first_chunker()
        self.second_chunker()
        df_chunks = self.create_dataframe()
        
        return df_chunks
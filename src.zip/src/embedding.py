import openai
from openai import OpenAI
import os

class Embedder:
    """
    A class designed to handle the embedding of text using OpenAI's API. This class
    is particularly set up to work with a DataFrame containing text chunks, and
    it adds embeddings for these chunks as a new column in the DataFrame.
    """

    def __init__(self, df_chunks):
        """
        Initializes the Embedder with a DataFrame containing text chunks.

        Args:
            df_chunks (pd.DataFrame): A DataFrame with at least one column named 'chunk'
                                      that contains text data to be embedded.
        """
        self.df_chunks = df_chunks
        self.client = OpenAI()
        openai.api_key = os.getenv('OPENAI_API_KEY')
        

    def get_embedding(self, text, model="text-embedding-3-small"):
        """
        Fetches the embedding for a given text using a specified model from the OpenAI API.

        Args:
            text (str): The text for which embedding is required.
            model (str): The model identifier to be used for generating embeddings. Default is "text-embedding-3-small".

        Returns:
            np.array: The embedding vector for the given text.
        """
        text = text.replace("\n", " ")
        return self.client.embeddings.create(input = [text], model=model, dimensions=256).data[0].embedding
    
    def trigger_embedder(self):
        """
        Applies the embedding process to each text chunk in the DataFrame and stores the results
        in a new column of the DataFrame.

        This method updates the DataFrame in-place, adding a column named 'ada_embedding' that
        contains the embeddings of the text chunks.
        """
        self.df_chunks['ada_embedding'] = self.df_chunks['chunk'].apply(lambda x: self.get_embedding(x, model='text-embedding-3-small'))
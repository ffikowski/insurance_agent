import numpy as np
import re
import spacy
from nltk.corpus import stopwords

from sklearn.feature_extraction.text import TfidfVectorizer


class TopicModeller:
    """
    A class for topic modeling which processes a corpus of German text documents
    using various natural language processing techniques including lemmatization,
    stop words removal, and TF-IDF vectorization.
    """

    def __init__(self, corpus):
        """
        Initializes the TopicModeller with a specific corpus.
        
        Args:
            corpus (list of str): A list of documents in the form of strings.
        """
        self.corpus = corpus
        self.nlp = spacy.load("de_core_news_sm")
        self.german_stopwords = set(stopwords.words('german'))
        self.vectorizer = TfidfVectorizer()
        

    def preprocess_regex(self):
        """
        Preprocesses the corpus using regular expressions to clean up the text.
        This includes removing newline characters and extra spaces, and simplifying
        repeated word and space patterns.
        """
        self.corpus = [doc.replace("\n", " ") for doc in self.corpus]
        self.corpus = [re.sub(r'\s+', ' ', doc) for doc in self.corpus]
        self.corpus = [re.sub(r'(\w\s){3,}', ' ', doc) for doc in self.corpus]

    def preprocess_tfid(self):
        """
        Further preprocesses the corpus to prepare for TF-IDF vectorization,
        focusing on alphabetic characters and lowercasing.
        
        Returns:
            list of list of str: A list of documents, each represented as a list of words.
        """
        preprocessed_corpus = []

        for k in np.arange(len(self.corpus)):
            text= ""
            for i in np.arange(len(self.corpus[k])):
                if self.corpus[k][i].isalpha() or self.corpus[k][i].isspace():
                    text += self.corpus[k][i].lower()
            text_split = text.split()
            preprocessed_corpus.append(text_split)
        return preprocessed_corpus
    
    def lemmatize_doc(self, doc):
        """
        Lemmatizes a single document using Spacy's NLP pipeline.

        Args:
            doc (list of str): A document represented as a list of words.

        Returns:
            list of str: Lemmatized version of the document.
        """
        # Join the words into a single string (since Spacy expects text input, not a list of tokens)
        text = " ".join(doc)
        # Process the text through the NLP pipeline
        processed_text = self.nlp(text)
        # Extract the lemmatized form of each word
        return [token.lemma_ for token in processed_text]
    
    def lemmatize(self, preprocessed_corpus):
        """
        Lemmatizes each document in the corpus.

        Args:
            preprocessed_corpus (list of list of str): Each document as a list of words.

        Returns:
            list of list of str: Lemmatized corpus.
        """
        return [self.lemmatize_doc(doc) for doc in preprocessed_corpus]
    
    def remove_stopwords_doc(self, doc):
        """
        Removes stop words from a single document.

        Args:
            doc (list of str): A document represented as a list of words.

        Returns:
            list of str: Document with stop words removed.
        """
        return [word for word in doc if word not in self.german_stopwords]
    
    def remove_stopwords(self, lemmatized_corpus):
        """
        Removes stop words from each document in the lemmatized corpus.

        Args:
            lemmatized_corpus (list of list of str): Lemmatized corpus.

        Returns:
            list of list of str: Corpus with stop words removed.
        """
        return [self.remove_stopwords_doc(doc) for doc in lemmatized_corpus]
    
    def joiner(self, cleaned_corpus):
        """
        Joins words in each document to form strings, necessary for vectorization.

        Args:
            cleaned_corpus (list of list of str): Corpus with processing completed.

        Returns:
            list of str: Each document as a single string.
        """
        for i in np.arange(len(cleaned_corpus)):
            value = ' '.join(cleaned_corpus[i])
            cleaned_corpus[i] = value
        return cleaned_corpus
    
    def fit_tfidf_matrix(self, cleaned_corpus):
        """
        Fits the TF-IDF vectorizer to the cleaned corpus and transforms it.

        Args:
            cleaned_corpus (list of str): Each document as a single string.

        Returns:
            scipy.sparse.csr.csr_matrix: TF-IDF matrix of the corpus.
        """
        X = self.vectorizer.fit_transform(cleaned_corpus)
        return X
    
    def top_tfidf_words(self, tfidf_matrix, feature_names, top_n=7):
        """
        Identifies the top TF-IDF words in each document of the corpus.

        Args:
            tfidf_matrix (scipy.sparse.csr.csr_matrix): The TF-IDF matrix of the corpus.
            feature_names (list of str): List of feature names from the TF-IDF vectorizer.
            top_n (int): Number of top words to retrieve for each document.

        Returns:
            list of list of str: Top words for each document in the corpus.
        """
        top_words_corpus = []

        for doc_idx, doc in enumerate(tfidf_matrix):
            print(f"Document {doc_idx + 1}:")
            # Sort the TF-IDF values in descending order and get the indices
            sorted_indices = np.argsort(doc.toarray()).flatten()[::-1]
            # Get the top n words with the highest TF-IDF scores
            top_words = [feature_names[idx] for idx in sorted_indices[:top_n]]
            for word in top_words:
                print(f"{word}")

            top_words_corpus.append(top_words)
            print()  # Print a newline for better readability

        return top_words_corpus
    
    def get_feature_names(self):
        """
        Retrieves the feature names generated by the TF-IDF vectorizer.

        Returns:
            np.ndarray: Array of feature names.
        """
        return self.vectorizer.get_feature_names_out()
    
    def trigger_tfidf(self):
        """
        Orchestrates the complete TF-IDF processing and top word extraction for the corpus.

        Returns:
            list of list of str: Top TF-IDF words for each document in the corpus.
        """
        self.preprocess_regex()
        preprocessed_corpus = self.preprocess_tfid()
        lemmatized_corpus = self.lemmatize(preprocessed_corpus)
        cleaned_corpus = self.remove_stopwords(lemmatized_corpus)
        cleaned_corpus = self.joiner(cleaned_corpus)
        X = self.fit_tfidf_matrix(cleaned_corpus)
        feature_names = self.get_feature_names()
        top_words_corpus = self.top_tfidf_words(feature_names=feature_names, tfidf_matrix=X, top_n=7)
        
        return top_words_corpus
